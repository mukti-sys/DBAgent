# DBAgent — Tests

No phase in Phases.md is complete without the tests below passing. This is the other file an autonomous loop must read before marking anything done.

## 1. Unit Tests (per module)
- `intent.py` — ambiguous vs. clear question classification; glossary term resolution
- `schema_retrieval.py` — correct tables/columns retrieved for a given question; drift detection catches renamed/removed columns
- `sql_generator.py` — valid SQL syntax (via `sqlglot` parse check) across a range of question types
- `verifier.py` — flags cartesian joins, flags queries referencing nonexistent tables/columns (hallucinated schema elements), flags queries touching unexpected tables, flags absurd row-count estimates
- `confidence.py` — score combination logic; threshold behavior at the boundary
- `correction_memory.py` — a stored rule is retrieved and applied on a matching future query
- `key_resolver.py` — candidate key matches ranked correctly; ambiguous cases flagged, not auto-joined
- `concurrency_guard.py` — timeout triggers correctly; circuit breaker opens under simulated load
- `llm_client.py` — routes to the configured provider/model per role; capability self-test correctly grades a compliant model as pass and a malformed/non-compliant stub as degraded or fail; simulated timeout/rate-limit triggers retry-with-backoff, then a clean `refused: model unavailable` — never a silent hang or a fabricated answer

## 2. Integration Tests
Full pipeline against a seeded test Postgres DB with a deliberately messy schema:
- inconsistent key types across two tables meant to join
- at least one renamed column (to test drift detection)
- at least one nullable FK
- a free-text "notes" field containing a crafted injection-style string (to test §3)
- a multi-turn scenario: a filtered question followed by "now break that down by X"
- the same suite re-run with `config/models.yaml` pointed at a second, different provider — confirms the abstraction isn't Anthropic-only in practice, not just on paper

## 3. Safety Tests (must never fail, ever)
- Natural-language request that implies a DROP/DELETE/UPDATE → must be blocked in default (read-only) mode
- Crafted SQL-injection-style user input → must be parameterized/escaped, never interpolated
- Crafted prompt-injection string inside a DB free-text field → agent must not follow embedded instructions from data

## 4. Eval Set (agent quality, not just code correctness)
- Small hand-labeled set: NL question → expected SQL (or accepted equivalents) → expected answer
- Include an easy tier (clear questions, clean schema) and a hard tier (ambiguous questions, messy schema, at least one question that *should* trigger a refusal)
- Score via execution-match, noted honestly as imperfect — two different correct SQL statements can both pass, or a semantically-wrong query can accidentally match
- Track accuracy and calibration (of refused/flagged answers, how many would've been wrong if forced) over time, not as a single pass/fail gate

## 5. Regression Tests
Every user-reported correction gets added here as a permanent test case once fixed, so it can never silently regress.

## 6. Running Tests
```bash
pytest tests/unit
pytest tests/integration   # requires seeded test DB, see tests/integration/README
pytest tests/safety
pytest tests/eval          # produces accuracy/calibration report, not pass/fail
```
