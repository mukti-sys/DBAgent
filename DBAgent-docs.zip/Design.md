# DBAgent — Design

This is a developer tool first — visual design is secondary to output clarity. Interaction design is the real design surface here, not colors/fonts, until a UI actually exists.

## 1. Output Format (CLI / API response shape)
Every answer follows the same structure, in this order:
1. **Interpretation** — plain-language restatement of what's being answered ("Reading this as: total revenue by region, last 12 months")
2. **SQL** — the exact generated query, always shown, syntax-highlighted if the interface supports it
3. **Confidence** — one of `high` / `flagged: <reason>` / `refused: <reason>` — never hidden, never omitted
4. **Answer** — narrated result, with real computed numbers substituted in
5. **Notes** (optional) — assumptions made, glossary terms used, a known-limitation trigger (e.g. "dirty-key match confirmed with you earlier"), or a persistent warning if the configured model is running in `degraded` mode per its capability self-test (Phase 8.5) — every response, not just the first, until reconfigured

## 2. Confidence Signaling
- `high` — plain text, no extra markup
- `flagged` — clearly marked, reason stated in one sentence, answer still shown but caveated
- `refused` — no answer given, states exactly what's missing (e.g. "I don't have a confirmed join between `orders.cust_id` and `customers.id` — confirm this mapping?")

## 3. Tone
- Plain, hedged appropriately, never falsely confident — matches Rules.md §2.
- No filler ("Great question!"), no over-apologizing on refusal — state the limitation and what would resolve it.

## 4. Future UI (post-CLI, not in scope for v1)
- Monospace for SQL, clear visual separation between interpretation / SQL / answer
- Confidence color-coding: green (`high`), yellow (`flagged`), red (`refused`) — functional, not decorative
- Inline "correct this" affordance feeding directly into `correction_memory` (Phase 8)

## 5. Logging / Observability Design
- Every pipeline stage (intent, retrieval, generation, verification, confidence, execution) logs structured output for debugging and for feeding the eval harness — not just the final answer.
