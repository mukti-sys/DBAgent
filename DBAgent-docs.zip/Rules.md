# DBAgent — Rules

These are hard constraints for anyone (human or AI) building this project. This file exists so no session — including a fresh chat with no memory of prior conversations — quietly drifts from them.

## 1. Security Rules (non-negotiable)
- Default DB role is **read-only**, enforced at the database user level — not just checked in application code.
- Never interpolate user input directly into SQL strings. Use parameterized queries / the query builder only.
- Block DDL/DML (DROP, DELETE, UPDATE, INSERT, ALTER, TRUNCATE) unless an explicit write-mode is enabled, and even then require a separate confirmation step before executing.
- Treat any free-text data pulled from the database (comments, notes fields, user-generated content) as untrusted input — see §4, indirect prompt injection.
- API keys/credentials live in environment variables or a secrets manager — never hardcoded, never committed, never written into logs or error messages.
- If the user configures a local model, no pipeline stage may silently fall back to an external API instead — including schema embeddings. Everything routes through the same configured provider (`llm_client`, including its `embed()` calls), or a local setup doesn't actually deliver the privacy/air-gap guarantee the user chose it for.

## 2. Honesty Rules (the actual point of this project)
- Never present an unsolved problem as solved. If a mechanism is a best-effort mitigation (see §4), the code, docs, and any user-facing text must say so — "best-effort" or "flagged for review," never "handled."
- If schema-match, join-derivation, or result-sanity confidence is below threshold, refuse or flag — do not answer anyway and hope.
- Always show the generated SQL next to the answer. No exceptions, no "cleaner" mode that hides it.
- Never let narration state a number the code hasn't actually computed from the real result set.

## 3. Engineering Rules
- **Use:** `sqlglot` for SQL parsing/analysis, `SQLAlchemy` for connections, `pytest` for tests.
- **Avoid:** raw string concatenation for SQL, dumping the entire schema into every prompt (retrieve only what's relevant), any dependency not justified in Architecture.md.
- Every module gets unit tests before it's considered done (see Tests.md). No phase in Phases.md is marked complete without passing tests.
- Config (glossary, thresholds, connection settings) lives in `config/`, not hardcoded.

## 4. Known Limitations — Handle Defensively, Never Silently

### Standard engineering (must-do, not novel — no excuse to skip these)
- **Access control** — read-only DB role; DDL/DML blocked unless write-mode is explicitly enabled with extra confirmation.
- **Schema drift** — schema index must be diffed and refreshed on connect; a renamed column or new migration should never silently produce wrong SQL.
- **Cost & latency** — a single query may cost 2-4 LLM calls plus DB compute; this must be budgeted and monitored, not discovered in production.
- **API reliability** — retry transient failures (timeout, rate limit) with backoff; on persistent failure, surface `refused: model unavailable` — never hang silently or fabricate an answer because the model call failed.

### Genuinely unresolved (build the best mitigation, disclose the rest — never claim these are solved)
- **Schema/SQL hallucination** — the LLM can still reference a table, column, or join that doesn't exist, or invent a plausible-looking join with no real key relationship, even with retrieval grounding. Mitigated by schema retrieval narrowing what's available to reference (Phase 2), the verifier catching nonexistent-reference errors (Phase 5), and schema-match confidence in the gate (Phase 6) — not eliminated by any of them individually.
- **Multi-DB dirty keys** — no universal resolver exists. Propose candidate joins with a confidence score; confirm ambiguous ones with the user once; remember the answer. Never silently guess a join across inconsistent keys.
- **Query optimization under concurrent agentic load** — not attempting a new optimizer. Use EXPLAIN-based cost estimates plus a timeout/circuit-breaker so expensive queries are flagged or throttled, not left to silently degrade production.
- **Multi-turn conversational SQL** — benchmarks (CoSQL, SParC) show a real accuracy drop vs. single-turn. Track session state (filters, prior result context) carefully; when state tracking is uncertain, ask rather than assume.
- **Result narration hallucination** — SQL and data can be fully correct and the model can still misstate something when summarizing it. Mitigated (not eliminated) by substituting real computed values into narration templates instead of letting the model restate numbers from memory (see Architecture.md §5).
- **Conflicting business definitions** — e.g. three teams defining "revenue" differently. Not an AI problem to solve. Surface the conflict via the glossary layer; do not silently pick one team's definition.
- **Evaluating the agent itself** — no labeled eval set exists off-the-shelf for a given DB, and execution-match isn't fully reliable (two different SQL statements can both be correct). Build and grow a small hand-labeled eval set as part of the project, not after it (see Tests.md §4).
- **Indirect prompt injection via data** — free-text DB fields could contain crafted text aimed at the agent itself. Sanitize/flag suspicious content pulled from the DB before it re-enters the agent's context, especially once the agent has any tool access beyond pure read.
- **Model-dependent reliability** — the confidence gate, hallucination mitigation, and structured-output parsing all assume the underlying model reliably follows instructions and returns valid structured output. That assumption gets weaker, not stronger, with local/open-weight models, which G10 explicitly allows the user to choose. Mitigated by a capability self-test on every new provider/model configuration (Phase 8.5) that grades it pass/degraded/fail before it's trusted in the pipeline — not eliminated. A model that fails the self-test is refused as a configuration choice, with a clear reason; it is never silently allowed to run the agent at reduced reliability without saying so.

## 5. Scope Boundaries
Restated from PRD.md §4 as hard rules, not aspirations:
- Do not attempt to build a general-purpose query optimizer.
- Do not attempt fully automatic, unconfirmed dirty-key resolution.
- Do not attempt to adjudicate conflicting business definitions on the org's behalf.
- Do not enable write access without an explicit, separately-confirmed write-mode.
