# DBAgent — Memory (state snapshot, not a log)

## How to use this file (read before editing)
This file exists to save tokens, not spend them — it lets a new session get up to speed by reading one short file instead of re-scanning the whole codebase or guessing at prior progress. That only works if it stays short:
- **Overwrite, don't append.** Replace the "Current State" section on each update; don't keep a growing history below it.
- Keep it to the essentials: what's done, what's next, and any open decision — not a diary of every step taken.
- If it starts creeping past roughly one page, prune it. Old detail belongs in commit messages or Phases.md checkmarks, not here.

## Current State
- **Last updated:** (not started yet)
- **Current phase:** Phase 0 — Scaffolding (not yet started)
- **Completed phases:** none
- **Open decisions:** none yet
- **Known blockers:** none yet

## Next Action
Start Phase 0 per Phases.md and Goal.md.
