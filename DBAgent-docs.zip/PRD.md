# DBAgent — Product Requirements Document

(Working codename — rename freely, nothing below depends on the name.)

## 1. Problem Statement
Text-to-SQL agents fail in three specific, recurring ways:
1. They hallucinate table/column names and invent plausible-but-wrong joins on messy or unfamiliar schemas.
2. They treat ambiguous questions as clear and answer anyway, instead of checking what the user actually meant.
3. They present wrong or logically-broken SQL with the same confidence as correct SQL — there's no signal to tell the two apart.

Even frontier agents remain well short of reliable on realistic, messy enterprise schemas — independent tracking on Spider 2.0-style benchmarks puts current best performance roughly in the 20-55% range depending on benchmark version and date, nowhere close to solved. DBAgent does not claim to raise that ceiling. It claims to be honest about it: showing its work, flagging uncertainty, and refusing rather than guessing when it lacks the signal to answer safely.

## 2. Target Users
- **Primary:** developers and data analysts who need to query a database in natural language without re-deriving SQL/join logic every time.
- **Secondary:** small teams who want an internal BI copilot they can trust not to silently return a wrong number.

## 3. Goals (in scope)
- **G1** — Reconstruct user intent before running anything; ask a clarifying question when the request is genuinely ambiguous.
- **G2** — Retrieve only relevant schema context (not the whole schema) to reduce hallucinated columns.
- **G3** — Generate SQL, then verify it (EXPLAIN, join-safety, row-count sanity) before showing a result.
- **G4** — Score confidence from concrete signals (schema-match quality, join-derivation, result sanity) and refuse below threshold instead of guessing.
- **G5** — Always show the generated SQL alongside the answer.
- **G6** — Persist user corrections as org-specific rules so the same mistake isn't repeated.
- **G7** — Handle multi-DB / inconsistent join keys defensively: propose candidate matches with confidence, confirm once, remember.
- **G8** — Protect production databases: read-only by default, query timeout/circuit breaker under load.
- **G9** — Track conversational context across turns ("now break that down by region") with graceful degradation, not silent failure.
- **G10** — Support any LLM provider (Anthropic, OpenAI, Google, open-weight model APIs, local models) through one interface; the user picks provider and model per pipeline role, not locked to a single vendor or a fixed model list.

## 4. Explicit Non-Goals (out of scope, and why)
- **A general-purpose query optimizer** — unsolved at the research level. DBAgent adds a safety/throttling layer, not a new optimizer.
- **Fully automatic dirty-key resolution with no confirmation** — nobody has this solved. DBAgent asks once and remembers instead of guessing silently.
- **Resolving conflicting business definitions across teams** (e.g. three teams' definitions of "revenue") — this is an org data-governance problem, not something a tool can decide on the org's behalf. DBAgent surfaces the conflict; it doesn't adjudicate it.
- **Unrestricted write access by default** — write operations require an explicit opt-in write-mode with a separate confirmation step (see Rules.md).

## 5. Success Metrics
- Accuracy on a hand-built internal eval set (see Tests.md) — tracked over time, not a one-time number.
- Calibration: of the answers DBAgent refuses or flags as low-confidence, what fraction would actually have been wrong? Should trend toward "most of them."
- Correction rate should decrease over time as the correction-memory layer accumulates rules for a given database.
- Zero unsafe writes in read-only mode — verified by tests, not assumed.

## 6. Constraints
- **Cost/latency:** a single query may involve 2-4 LLM calls (intent check, generation, possible retry, narration) — budget accordingly.
- **Security:** default read-only; no raw string interpolation of user input into SQL, ever (see Rules.md).
- Must degrade gracefully, never silently, when it hits one of the genuinely unresolved problems listed in Rules.md §4.
- Letting the user choose any provider/model (G10) is not risk-neutral: confidence-gate accuracy and hallucination rate both depend on the underlying model's capability. See Rules.md §4, model-dependent reliability.
