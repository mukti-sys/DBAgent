# DBAgent — Phases

Each phase must be complete and its tests (see Tests.md) passing before moving to the next. Update Goal.md's checklist and Memory.md's state snapshot at the end of every phase.

## Phase 0 — Scaffolding
- Repo structure per Architecture.md §4
- `requirements.txt`, config loading, empty test harness wired to `pytest`
- **Exit criteria:** `pytest` runs (even with zero tests) with no errors

## Phase 1 — Access Control & Safety Layer
- Read-only DB role setup + enforcement
- DDL/DML blocking (with write-mode flag, disabled by default)
- Parameterized query wrapper (no raw string interpolation, ever)
- **Exit criteria:** safety tests in Tests.md §3 pass, including an attempted DROP/DELETE via crafted input

## Phase 2 — Schema Retrieval
- Schema indexer (embed table/column/relationship metadata)
- Drift detection + incremental refresh on connect
- **Exit criteria:** index correctly reflects schema after a simulated column rename/migration

## Phase 3 — Glossary & Intent Reconstruction
- Glossary store (`config/glossary.yaml`)
- Intent restatement step; ambiguity detection; clarifying-question flow
- **Exit criteria:** ambiguous test questions trigger a clarifying question instead of a guess

## Phase 4 — SQL Generation
- LLM wrapper using retrieved schema slice + glossary + correction memory (empty at this point)
- **Exit criteria:** generates syntactically valid SQL for the eval set's easy tier

## Phase 5 — Verification-First Mode
- EXPLAIN integration, join-cardinality check, cost/row-count sanity check
- **Exit criteria:** verifier flags a deliberately-broken cartesian-join test case AND a test case referencing a hallucinated (nonexistent) column

## Phase 6 — Confidence Gate
- Combine schema-match / join-confidence / result-sanity into one score
- Refusal/flagging behavior below threshold
- **Exit criteria:** agent refuses on a deliberately underspecified schema test case instead of guessing

## Phase 7 — Execution & Narration
- Read-only execution with timeout guard
- Narration via template + real computed values (not LLM-recalled numbers)
- **Exit criteria:** narration numbers match query results exactly across the eval set

## Phase 8 — Correction Memory
- Capture user corrections; persist as scoped rules (org/db-keyed)
- Apply stored rules on subsequent matching queries
- **Exit criteria:** a corrected mistake does not recur on a repeat/near-repeat question

## Phase 8.5 — Provider Abstraction (retrofit — added after G10)
This phase was added after Phases 2, 3, 4, 5, and 7 already existed, some calling the Anthropic API (or a hardcoded embedding provider) directly. It is a retrofit, not a bolt-on: those modules get refactored here, not left as-is.
- Build `llm_client.py`: a thin wrapper (LiteLLM under the hood) exposing `generate()`, `generate_structured()`, and `embed()`, used by every module that calls a model — completions and embeddings alike
- `config/models.yaml` schema: provider + model + credentials-env-var-name, settable per role (intent / generation / narration / verification-explanation / embeddings / escalation), defaulting to the Haiku/Sonnet/Opus routing in Architecture.md
- Model capability self-test, run once per newly configured provider/model: (1) valid structured/JSON output on a canary prompt, (2) correctly declines a deliberately unanswerable canary question against the seeded test schema, (3) tool-calling works if the role requires it. Grade pass / degraded / fail — degraded surfaces a persistent warning in the Notes field (Design.md §1); fail blocks that model from being used
- Retrofit `intent.py`, `sql_generator.py`, `narrator.py`, `verifier.py` (its optional flagged-issue explanation call) to route through `llm_client` instead of any direct provider SDK call
- Retrofit `schema_retrieval.py`'s embedding generation to route through `llm_client.embed()` too — a user who configures a local model for privacy reasons needs schema/data to never leave the machine via a separately-hardcoded embedding call (see Rules.md §1)
- **Exit criteria:** the full Phase 2/3/4/5/7 test suite (Tests.md) passes unchanged when `config/models.yaml` is pointed at a second, different provider — proving the abstraction is real, not theoretical, and covers embeddings as well as completions. Capability self-test correctly fails a stub model that returns malformed output.

## Phase 9 — Multi-DB Dirty Key Handling (scoped, not "solved")
- Fuzzy key-matcher proposing candidate joins with confidence
- Confirm-once-remember flow
- **Exit criteria:** correctly flags an ambiguous key match instead of silently joining; remembers confirmation

## Phase 10 — Concurrency Guard (scoped, not "solved")
- Query timeout + circuit breaker under simulated concurrent load
- **Exit criteria:** expensive/concurrent queries are throttled or flagged, not left to degrade the DB

## Phase 11 — Multi-Turn Conversational State
- Session-scoped filter/context tracking
- Graceful degradation (ask, don't assume) when state is uncertain
- **Exit criteria:** "now break that down by region" correctly inherits prior filters in eval test cases

## Phase 12 — Eval Harness
- Hand-labeled eval set (grows over time)
- Execution-match + manual semantic-match scoring
- **Exit criteria:** harness runs end-to-end and produces an accuracy + calibration report

## Phase 13 — Indirect Prompt Injection Defense
- Sanitize/flag suspicious free-text field content before it re-enters agent context
- **Exit criteria:** a crafted injection payload in a test "comments" field is neutralized/flagged, not obeyed

## Phase 14 — Polish & Docs
- README, setup instructions, final pass on all .md files
- **Exit criteria:** a fresh environment can be set up and pass the full test suite from README instructions alone
