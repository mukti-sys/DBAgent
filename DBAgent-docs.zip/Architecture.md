# DBAgent — Architecture

## 1. High-Level Flow
```
User question
  → Intent Reconstruction (+ glossary lookup)
  → [ambiguous?] → clarifying question → user
  → Schema Retrieval (embedding search over indexed schema)
  → SQL Generation (LLM + retrieved schema + glossary + correction memory)
  → Verification (EXPLAIN, join-safety check, cost/row estimate)
  → Confidence Gate (schema-match + join-confidence + result-sanity)
  → [below threshold?] → refuse / flag uncertainty → user
  → Execute (read-only, timeout-guarded)
  → Result narration (programmatic values, not LLM-recalled numbers)
  → Show SQL + answer + confidence
  → Capture correction (if user corrects) → persist rule
```

## 2. Components

| Component | Responsibility |
|---|---|
| `llm_client` | Unified interface (LiteLLM under the hood) to any configured provider/model — Anthropic, OpenAI, Google, open-weight APIs, or local — for both completions and embeddings; handles per-role model selection, the escalation cascade, and a capability self-test before trusting a newly configured model (see Model Routing below) |
| `glossary_store` | Org-specific term definitions ("active user", "revenue", etc.) |
| `schema_indexer` | Embeds table/column/relationship metadata; detects drift on connect |
| `intent_reconstructor` | Restates the question in plain language against the glossary; decides if clarification is needed |
| `sql_generator` | LLM call using retrieved schema slice + glossary + correction memory |
| `verifier` | Runs EXPLAIN; checks join cardinality, touched tables, cost estimate |
| `confidence_scorer` | Combines schema-match / join-confidence / result-sanity into one gate decision |
| `executor` | Runs the query read-only, with timeout and circuit breaker |
| `narrator` | Turns results into prose, computing figures in code rather than letting the LLM restate numbers from memory |
| `correction_memory` | Persists user corrections as rules, scoped per org/DB |
| `key_resolver` | Fuzzy-matches candidate join keys across dirty/multi-DB schemas; asks once, remembers |
| `access_control` | Enforces read-only DB role; blocks DDL/DML unless write-mode is explicitly enabled |
| `concurrency_guard` | Query timeout + circuit breaker under concurrent load |
| `eval_harness` | Runs the hand-built eval set; tracks accuracy/calibration over time |

## 3. Tech Stack
- **Language:** Python 3.11+
- **LLM:** provider-agnostic through `llm_client` (LiteLLM under the hood) — one interface across Anthropic, OpenAI, Google, any open-weight model API, and local models served via an OpenAI-compatible endpoint (Ollama, vLLM, etc.). Ships with Anthropic-model defaults; the user repoints `config/models.yaml`, not code, to switch.
- **SQL parsing/analysis:** `sqlglot`
- **DB connectivity:** `SQLAlchemy` (read-only role enforced at the DB user level, not just app level)
- **Schema embeddings:** generated via `llm_client.embed()` (same provider-agnostic path as everything else) into a local vector store (e.g. Chroma); swap for pgvector later if scale demands it
- **Testing:** `pytest`
- **Target DB for v1:** PostgreSQL (multi-DB support is Phase 9+, see Phases.md)

### Model Routing (per pipeline stage — not one model for everything)
| Stage | Default | Escalate to | Why |
|---|---|---|---|
| Intent reconstruction / ambiguity check | Haiku | — | Classification-scale task, not frontier reasoning |
| SQL generation | Sonnet | Opus, only when `confidence_scorer` flags low schema-match or join-confidence | Core reasoning step; escalate on the model's own uncertainty signal, not by default |
| Verification (EXPLAIN interpretation) | code, not LLM | Haiku, only for a natural-language explanation of a flagged issue | Deterministic checks belong in code |
| Narration | Haiku | — | Numbers are substituted from real results, not computed by the model — cheap model is enough for phrasing |

Model IDs live in `config/models.yaml`, never hardcoded in `src/`, so a pricing, version, or provider change doesn't touch code. This is the concrete version of PRD.md §6's "2-4 LLM calls per query": typically 1 cheap-tier call (intent) + 1 mid-tier call (generation) + 1 cheap-tier call (narration), reaching for the top tier only on flagged low-confidence cases. The Haiku/Sonnet/Opus example above is the shipped default if using Anthropic — per PRD.md §3 G10, the user can point `config/models.yaml` at OpenAI, Google, an open-weight API, or a local model instead, and the same cheap→strong escalation pattern applies within whatever provider is configured. Every module routes through `llm_client` (§2) — nothing calls a provider SDK directly.

## 4. File / Folder Structure
```
db-agent/
├── PRD.md
├── Architecture.md
├── Rules.md
├── Phases.md
├── Design.md
├── Goal.md
├── Tests.md
├── Memory.md
├── src/
│   ├── agent/
│   │   ├── llm_client.py
│   │   ├── glossary.py
│   │   ├── intent.py
│   │   ├── schema_retrieval.py
│   │   ├── sql_generator.py
│   │   ├── verifier.py
│   │   ├── confidence.py
│   │   ├── executor.py
│   │   ├── narrator.py
│   │   ├── correction_memory.py
│   │   ├── key_resolver.py
│   │   └── concurrency_guard.py
│   ├── db/
│   │   ├── connector.py
│   │   └── access_control.py
│   └── interface/
│       └── cli.py
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── safety/
│   └── eval/
├── config/
│   ├── glossary.yaml
│   └── models.yaml
└── requirements.txt
```

## 5. Data Flow Notes
- Schema index is diffed and incrementally refreshed whenever a drift check on connect finds new/renamed/removed columns — never a silent full rebuild that masks what changed.
- Correction memory is keyed per `(org_id, db_fingerprint)` so rules never leak across unrelated databases.
- Narration never lets the LLM recompute a number that's already in the query result — it substitutes the real value into a template instead, to reduce the "correct SQL, wrong sentence" failure mode.
