# DBAgent — Goal

## Purpose of this file
This is the file an autonomous coding loop reads first. Read this, then Memory.md (current state), then work on the next unchecked item below. Do not stop until every item is checked and its tests pass.

## Definition of Done
The project is done when:
- [ ] Every phase in Phases.md is complete with passing tests (Tests.md)
- [ ] No rule in Rules.md has been violated (spot-check before declaring done, don't assume)
- [ ] Every "genuinely unresolved" item in Rules.md §4 has a working best-effort mitigation in code — not a TODO, not a stub
- [ ] `pytest` passes clean, full suite, from a fresh clone following README setup steps
- [ ] Memory.md reflects the final state accurately

## Loop Instructions (for the AI executing this)
1. Read Memory.md for current state before doing anything else. Don't re-derive context by re-reading the whole codebase if Memory.md already has it.
2. Pick the next unchecked phase below (matches Phases.md).
3. Implement it per Architecture.md and Rules.md.
4. Write tests per Tests.md for that phase. Run them.
5. Only check the box if tests pass. If they don't, keep working the same phase — do not move on and do not check the box.
6. Update Memory.md with a short state snapshot (what's done, what's next, any open decision) — overwrite stale info, don't append forever.
7. Repeat from step 2 until every box is checked.
8. Never mark a "genuinely unresolved" item's phase complete by claiming it's "solved." Complete means "best-effort mitigation implemented and tested," per Rules.md §2.

## Checklist
- [ ] Phase 0 — Scaffolding
- [ ] Phase 1 — Access Control & Safety Layer
- [ ] Phase 2 — Schema Retrieval
- [ ] Phase 3 — Glossary & Intent Reconstruction
- [ ] Phase 4 — SQL Generation
- [ ] Phase 5 — Verification-First Mode
- [ ] Phase 6 — Confidence Gate
- [ ] Phase 7 — Execution & Narration
- [ ] Phase 8 — Correction Memory
- [ ] Phase 8.5 — Provider Abstraction (retrofit)
- [ ] Phase 9 — Multi-DB Dirty Key Handling
- [ ] Phase 10 — Concurrency Guard
- [ ] Phase 11 — Multi-Turn Conversational State
- [ ] Phase 12 — Eval Harness
- [ ] Phase 13 — Indirect Prompt Injection Defense
- [ ] Phase 14 — Polish & Docs

## If Stuck
If the same phase fails 3 loop iterations in a row, stop looping and write the blocker clearly in Memory.md instead of retrying blindly — a human needs to look at it. Burning tokens on a 4th, 5th, 6th identical attempt is not progress.
